<?php

require "rb.php";

R::setup('mysql:host=localhost;dbname=casamar5_montas',

	'root', 'root');

?>